"""Defines the constant INFINITY = 65535."""
INFINITY: int = 65535
""" int: 65535 """
